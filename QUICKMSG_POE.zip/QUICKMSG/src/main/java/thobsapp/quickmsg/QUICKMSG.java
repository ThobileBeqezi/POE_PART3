package thobsapp.quickmsg;

import javax.swing.*;

/**
 * 
 * @author Thobile
 */
public class QUICKMSG {

    // This is the storing messages process
    private static final int MAX_MESSAGES = 50;
    private String[] messageIDs      = new String[MAX_MESSAGES];
    private String[] messageHashes   = new String[MAX_MESSAGES];
    private String[] recipients      = new String[MAX_MESSAGES];
    private String[] messageTexts    = new String[MAX_MESSAGES];
    private String[] messageStatuses = new String[MAX_MESSAGES];
    private int messageCount = 0;

    //Main program entry point method 
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            
            // Creating an object of this class
            QUICKMSG app = new QUICKMSG();

            // Load  the test data and start running the menu
            app.populateWithTestData();
            app.showMainMenu();
        });
    }

    //This will show the main menu 
    private void showMainMenu() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.",
                "QuickChat", JOptionPane.INFORMATION_MESSAGE);

        int choice;
        do {
            String menu = """
                    Please choose an option:
                    0) Send a new message
                    1) Search by Message ID
                    2) Search by Recipient
                    3) Delete by Message Hash
                    4) Quit
                    """;

            String input = JOptionPane.showInputDialog(menu);
            // Cancel closes  the app
            if (input == null) return; 

            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null,
                        "Invalid option. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 0 -> sendNewMessage();
                case 1 -> searchByMessageID();
                case 2 -> searchByRecipient();
                case 3 -> deleteByMessageHash();
                case 4 -> JOptionPane.showMessageDialog(null, "Goodbye!");
                default -> JOptionPane.showMessageDialog(null,
                        "Invalid option. Please try again.");
            }
        } while (true);
    }

    //  Load the data test method
    private void populateWithTestData() {
        if (messageCount > 0) return;
    // Test data message 1
        messageIDs[0] = "100000001";
        messageHashes[0] = "101101DCAKE";
        recipients[0] = "+27834557896";
        messageTexts[0] = "Did you get the cake?";
        messageStatuses[0] = "Sent";
       
    //Test data message 2
        messageIDs[1] = "100000002";
        messageHashes[1] = "101:WHERE TIME";
        recipients[1] = "+27838845677";
        messageTexts[1] = "Where are you? You are late!";
        messageStatuses[1] = "Stored";
        
    // Test data message 3
        messageIDs[2] = "100000003";
        messageHashes[2] = "101:YHOODGATE";
        recipients[2] = "+27834484567";
        messageTexts[2] = "Yohoooo, I am at your gate.";
        messageStatuses[2] = "Disregarded";

    // Test data message 4
        messageIDs[3] = "100000004";
        messageHashes[3] = "101:ITTIME";
        recipients[3] = "0838845677";
        messageTexts[3] = "It is dinner time!";
        messageStatuses[3] = "Sent";

    // Test data message 5    
        messageIDs[4] = "100000005";
        messageHashes[4] = "101:OKYOU";
        recipients[4] = "+27838884567";
        messageTexts[4] = "OK, I am leaving without you.";
        messageStatuses[4] = "Stored";

        messageCount = 5;
    }

    // This is the send new message method
    private void sendNewMessage() {
        if (messageCount >= MAX_MESSAGES) {
            JOptionPane.showMessageDialog(null,
                    "Message storage is full!", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String recipient = JOptionPane.showInputDialog(
                "Enter recipient's phone number (e.g., +2783...):");
        if (recipient == null || recipient.trim().isEmpty()) return;

        String text = JOptionPane.showInputDialog("Enter message text:");
        if (text == null || text.trim().isEmpty()) return;

        String id = String.format("%09d", 100000000 + messageCount + 1);
        String hash = Integer.toHexString(text.hashCode()).toUpperCase();
        String status = "Sent";

        messageIDs[messageCount]      = id;
        messageHashes[messageCount]   = hash;
        recipients[messageCount]      = recipient.trim();
        messageTexts[messageCount]    = text.trim();
        messageStatuses[messageCount] = status;
        messageCount++;

        JOptionPane.showMessageDialog(null,
                "Message sent successfully!\nID: " + id + "\nHash: " + hash,
                "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    // Search messages by ID method
    private void searchByMessageID() {
        String id = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (id == null || id.isBlank()) return;

        for (int i = 0; i < messageCount; i++) {
            if (id.equals(messageIDs[i])) {
                JOptionPane.showMessageDialog(null, """
                        Message Found:
                        • ID: %s
                        • Recipient: %s
                        • Message: %s
                        • Status: %s
                        """.formatted(messageIDs[i], recipients[i],
                        messageTexts[i], messageStatuses[i]));
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }

    // Search by Recipient information 
    private void searchByRecipient() {
        String rec = JOptionPane.showInputDialog(
                "Enter recipient number to search:");
        if (rec == null || rec.isBlank()) return;

        StringBuilder results = new StringBuilder();
        for (int i = 0; i < messageCount; i++) {
            if (rec.equals(recipients[i])) {
                results.append("ID: ").append(messageIDs[i]).append("\n")
                        .append(messageTexts[i]).append("\n")
                        .append("Status: ").append(messageStatuses[i]).append("\n\n");
            }
        }

        if (results.isEmpty())
            JOptionPane.showMessageDialog(null, "No messages found.");
        else {
            JTextArea area = new JTextArea(results.toString(), 10, 40);
            area.setEditable(false);
            JOptionPane.showMessageDialog(null, new JScrollPane(area),
                    "Messages for " + rec, JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // Delete by message HASH 
    private void deleteByMessageHash() {
        String hash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
        if (hash == null || hash.isBlank()) return;

        int index = -1;
        for (int i = 0; i < messageCount; i++) {
            if (hash.equals(messageHashes[i])) { index = i; break; }
        }

        if (index == -1) { 
            JOptionPane.showMessageDialog(null, "Message hash not found.");
            return;
        }

        // Placing all elements on the left after they are cleared
        for (int i = index; i < messageCount - 1; i++) {
            messageIDs[i]      = messageIDs[i + 1];
            messageHashes[i]   = messageHashes[i + 1];
            recipients[i]      = recipients[i + 1];
            messageTexts[i]    = messageTexts[i + 1];
            messageStatuses[i] = messageStatuses[i + 1];
        }
        messageCount--;

        JOptionPane.showMessageDialog(null, "Message deleted successfully.");
    }
}


















































































































































































































































































































































