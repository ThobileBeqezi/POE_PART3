/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package thobsapp.quickmsg;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Thobile
 */
public class QUICKMSGIT {
    
    public QUICKMSGIT() {
    }

    @Test
    public void testMain() {
    }
    
}
